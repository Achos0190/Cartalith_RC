# Cartalith Sample Pack — CREDITS

All art in this pack is **procedurally generated** by `assets/make_sample_pack.py` and is
released into the public domain under **CC0 1.0**. No attribution required.

It exists as a reference/smoke-test pack for the in-app asset importer
(`docs/ASSET_PACK_FORMAT.md`). Swap in real CC0 art (see `docs/research/asset-candidates.md`)
by replacing the PNGs and keeping the same `pack.json` / `pack.csv` slot names.
